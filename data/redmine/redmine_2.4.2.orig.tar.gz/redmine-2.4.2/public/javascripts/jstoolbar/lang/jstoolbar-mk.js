jsToolBar.strings = {};
jsToolBar.strings['Strong'] = 'Задебелен';
jsToolBar.strings['Italic'] = 'Закосен';
jsToolBar.strings['Underline'] = 'Подвлечен';
jsToolBar.strings['Deleted'] = 'Прецртан';
jsToolBar.strings['Code'] = 'Код';
jsToolBar.strings['Heading 1'] = 'Заглавје 1';
jsToolBar.strings['Heading 2'] = 'Заглавје 2';
jsToolBar.strings['Heading 3'] = 'Заглавје 3';
jsToolBar.strings['Unordered list'] = 'Неподредена листа';
jsToolBar.strings['Ordered list'] = 'Подредена листа';
jsToolBar.strings['Quote'] = 'Цитат';
jsToolBar.strings['Unquote'] = 'Отстрани цитат';
jsToolBar.strings['Preformatted text'] = 'Форматиран текст';
jsToolBar.strings['Wiki link'] = 'Врска до вики страна';
jsToolBar.strings['Image'] = 'Слика';

